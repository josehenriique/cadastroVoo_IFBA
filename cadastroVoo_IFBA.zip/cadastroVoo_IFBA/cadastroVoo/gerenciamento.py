from datetime import date
import os
import json

class Gerenciamento:
    def __init__(self, name):
        self.name = name
    
    def cadastroVoo(self, info):

        filePath = os.path.join("db", "voos.json")

        def emptyFile(path):
            with open(path, 'r') as file:
                content = file.read()
            
            if not content:
                return True
            else:
                return False
        
        print(int(info['dataVoo'][0]), int(info['dataVoo'][2]), int(info['dataVoo'][1]))
    
        voo = {
            "numeroVoo" : info['numeroVoo'],
            "dataVoo" : date(int(info['dataVoo'][0]), int(info['dataVoo'][2]), int(info['dataVoo'][1])).isoformat(),
            "origemVoo" : info['origem'],
            "destinoVoo" : info['destino'],
            "vagasVoo" : 100,
        }
        

        with open(filePath, "r") as file:
            voosUpdate = json.load(file)
        
        if emptyFile(filePath):
            voosUpdate = []
        
        voosUpdate.append(voo)

        with open(filePath, 'w') as file:
            json.dump(voosUpdate, file)

        with open(filePath, 'r') as file:
            voosCadastro = json.load(file)
            print(voosCadastro)

        return {"voo": voo, "verification": True}