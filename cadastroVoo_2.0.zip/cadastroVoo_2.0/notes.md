# Trabalho de LP1

## Detalhes do sistema
> Voo
- Número
- Origem 
- Destino

> Avião
- 100 vagas

## Funcionalidades

> Menu
- ver voos cadastrados
    - número do voo
    - data do voo
    - origem do voo
    - destino do voo
    - número da próxima cadeira livre
    - verificar cadeira [função]
        - vai perguntar um número para o usuário e dizer se essa cadeira está livre ou ocupada
    - números de vagas livres

- cadastrar novos voos [função]
    - perguntar ao usuário os dados dos voos e guardá-los. (dados acima) [função]

- adicionar passageiro a um voo [função]
    - perguntar voo já cadastrado
    - reservar assento [função]
        - se tiver lotado deverá emitir uma mensagem

- listar voos do dia
    -  listar voos do dia de hoje
- [sair]

> os dados do voos (voos cadastrados) deverão ser armazedados permanentemente